import logo from "./logo.svg";
import "./App.css";
import Header from "./components/layouts/Header";
import Landing from "./components/layouts/Landing";
import Footer from "./components/layouts/Footer";
import { BrowserRouter } from "react-router-dom";
import Routers from "./components/routers/Routers";
import { Provider } from "react-redux";
import store from "./redux/store";

function App() {
  const appName = "KHUpgradeDevConnector";
  return (
    <>
      <Provider store={store}>
        <BrowserRouter>
          <Header appName={appName}></Header>
          <Routers></Routers>
          <Footer></Footer>
        </BrowserRouter>
      </Provider>
    </>
  );
}

export default App;
