import React from "react";

const Header2 = ({ appName }) => {
  return <div>Header2 {appName}</div>;
};

export default Header2;
