import api from "../../utils/api";
import { REGISTER_SUCCESS } from "../types";

export const register = (data) => (dispatch) => {
  //1. rest call
  // depending on result we needvto update the store.
  api
    .post("/users", data)
    .then((res) => {
      dispatch({ type: REGISTER_SUCCESS, payload: res.data.token });
    })
    .catch((err) => {});
};

// export : will give the access outside the file.
// const : const declarations
// register : name of the method/function.
// data : argument which will provide us the user details for registration
// dispatch : will help us to connect with thunk to sahre the data with reducer.
