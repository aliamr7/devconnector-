import { REGISTER_SUCCESS } from "../types";

const initialState = {
  loading: true,
  isAuthenticated: false,
  user: null,
  token: localStorage.getItem("token"),
};

export default (state = initialState, action) => {
  const { type, payload } = action;
  switch (type) {
    case REGISTER_SUCCESS:
      localStorage.setItem("token", payload);
      return {
        ...state,
        isAuthenticated: true,
        loading: false,
        token: payload,
      };

    default:
      return state;
  }
};
